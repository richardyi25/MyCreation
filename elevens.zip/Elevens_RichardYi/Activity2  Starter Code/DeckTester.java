/**
 * This is a class that tests the Deck class.
 */
public class DeckTester {

	/**
	 * The main method in this class checks the Deck operations for consistency.
	 *	@param args is not used.
	 */
	public static void test(Deck d){
		System.out.println("Deck is empty: " + d.isEmpty());
		while(!d.isEmpty()){
			System.out.println("Size of the deck: " + d.size());
			System.out.println("Card dealt from deck: " + d.deal());
		}
		System.out.println(d);
		System.out.println("----");
	}

	public static void main(String[] args) {
		String r[] = {"Ace", "Two", "Three"};
		String s[] = {"Spades", "Spades", "Spades"};
		String s2[] = {"Diamonds", "Diamonds", "Diamonds"};
		String s3[] = {"Spades", "Diamonds", "Diamonds"};
		int v[] = {1, 2, 3};

		Deck d = new Deck(r, s, v);
		Deck e = new Deck(r, s2, v);
		Deck f = new Deck(r, s3, v);

		test(d);
		test(e);
		test(f);
	}
}
