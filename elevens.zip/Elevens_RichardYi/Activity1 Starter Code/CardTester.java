/**
 * This is a class that tests the Card class.
 */
public class CardTester {

	/**
	 * The main method in this class checks the Card operations for consistency.
	 *	@param args is not used.
	 */
	public static void test(Card c){
		System.out.println("Suit: " + c.suit());
		System.out.println("Rank: " + c.rank());
		System.out.println("Point Value: " + c.pointValue());
		System.out.println(c);
	}

	public static void main(String[] args) {
		Card c = new Card("Ace", "Spades", 1);
		Card d = new Card("Ace", "Spades", 1);
		Card e = new Card("Three", "Spades", 3);
		
		test(c);
		test(d);
		test(e);

		System.out.println(c.matches(d));
		System.out.println(c.matches(e));
	}
}
